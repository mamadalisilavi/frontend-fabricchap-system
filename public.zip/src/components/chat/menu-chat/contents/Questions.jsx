export default function Questions() {
  return (
    <ul className="overflow-auto w-full h-52 flex flex-col justify-center items-center ">
      <li>qu 1</li>
      <li>qu 2</li>
      <li>qu 3</li>
      <li>qu 1</li>
      <li>qu 2</li>
      <li>qu 3</li>
      <li>qu 1</li>
      <li>qu 2</li>
      <li>qu 3</li>
      <li>qu 1</li>
      <li>qu 2</li>
      <li>qu 3</li>
      <li>qu 1</li>
      <li>qu 2</li>
      <li>qu 3</li>
      <li>qu 1</li>
      <li>qu 2</li>
      <li>qu 3</li>
      <li>qu 1</li>
      <li>qu 2</li>
      <li>qu 3</li>
      <li>qu 1</li>
      <li>qu 2</li>
      <li>qu 3</li>
    </ul>
  );
}
